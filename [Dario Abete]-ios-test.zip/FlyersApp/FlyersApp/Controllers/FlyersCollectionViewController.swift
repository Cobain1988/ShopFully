//
//  FlyersCollectionViewController.swift
//  FlyersApp
//
//  Created by Dario Abete on 23/09/2020.
//  Copyright © 2020 Dario Abete. All rights reserved.
//

import UIKit

class FlyersCollectionViewController: UICollectionViewController, ReachabilityObserver {
    
    let manager = APIManager()
    var flyerData = [Flyer]()
    var activityIndicator: UIActivityIndicatorView!
    var isReadFilterOn = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 13, *) {
            activityIndicator = UIActivityIndicatorView(style: .medium)
        } else {
            activityIndicator = UIActivityIndicatorView(style: .gray)
        }
        
        setActivityIndicator(indicator: activityIndicator, style: activityIndicator.style)
        activityIndicator.startAnimating()
        
        // MARK: Register cell classes
        self.collectionView!.register(UINib(nibName: "FlyersCell", bundle: nil), forCellWithReuseIdentifier: "FlyersCell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        try? self.addObserver()
        self.navigationItem.title = "Flyers List"
        self.collectionView!.reloadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.removeObserver()
    }
    
    @IBAction func toggleRead(_ sender: Any) {
        isReadFilterOn.toggle()
        self.navigationItem.rightBarButtonItem?.title = isReadFilterOn ? " Show all" : "Show read"
        self.collectionView.reloadData()
    }
    
    // MARK: Prepare for segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? FlyerDetailViewController, let item = sender as? Flyer {
            vc.item = item
        }
    }
    
    // MARK: Handling connection status
    func reachabilityChanged(_ isReachable: Bool) {
        if isReachable {
            if flyerData.isEmpty {
                self.populateView()
            }
        } else {
            self.displayMissingConnectionAlert()
        }
    }
    
    // MARK: UICollectionViewDataSource
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return isReadFilterOn ? flyerData.filter({$0.isRead == true}).count : flyerData.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let item = isReadFilterOn ? flyerData.filter({$0.isRead == true})[indexPath.item] : flyerData[indexPath.item]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FlyersCell", for: indexPath) as! FlyersCell
        cell.setup(text: item.title, isRead: item.isRead, imageView: item.imageView)
        return cell
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let item = isReadFilterOn ? flyerData.filter({$0.isRead == true})[indexPath.item] : flyerData[indexPath.item]
        self.performSegue(withIdentifier: "detailSegue", sender: item)
    }
}
