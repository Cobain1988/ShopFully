//
//  FlyerDetailViewController.swift
//  FlyersApp
//
//  Created by Dario Abete on 24/09/2020.
//  Copyright © 2020 Dario Abete. All rights reserved.
//

import UIKit

class FlyerDetailViewController: UIViewController {
    
    var item: Flyer?
    var timer: Timer?
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        timer = Timer.scheduledTimer(withTimeInterval: 0.001, repeats: true, block: { (_) in
            if let item = self.item {
                item.sessionDuration += 1
            }
        })
        sendFlyerOpenEvent()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard let item = item else { return }
        self.navigationItem.title = "Flyer #\(item.position + 1) detail page"
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if let timer = timer {timer.invalidate()}
        sendFlyerCloseEvent()
        if let item = item {
            item.resetStatus()
        }
        
    }
    
    func setup() {
        guard let item = item else { return }
        self.imageView.layer.borderColor = UIColor.black.cgColor
        self.imageView.layer.borderWidth = 2.0
        self.imageView.image = item.imageView?.image
        self.titleLabel.text = item.title
    }
    
    func sendFlyerOpenEvent() {
        guard let item = item else { return }
        let attributes: [String: Any] = ["retailer_id": Int(item.retailerId) ?? -1,
                                         "flyer_id": Int(item.id) ?? -1,
                                         "title": item.title,
                                         "position": item.position ,
                                         "first_read": !item.isRead]
                                        
        let event = Event(eventType: "flyer_open", attributes: attributes)
        let appIdentifier: String = retrieveAppBundleIdentifier()
        let appVersion: String = retrieveAppVersion()
        let analytics = StreamFully(appIdentifier: appIdentifier, appVersion: appVersion)
        analytics.process(event: event)
    }
    
    func sendFlyerCloseEvent() {
        guard let item = item else { return }
        let attributes: [String: Any] = ["flyer_id": Int(item.id) ?? -1,
                                         "session_duration": item.sessionDuration,
                                         "first_read": !item.isRead]
                                        
        let event = Event(eventType: "flyer_session", attributes: attributes)
        let appIdentifier: String = retrieveAppBundleIdentifier()
        let appVersion: String = retrieveAppVersion()
        let analytics = StreamFully(appIdentifier: appIdentifier, appVersion: appVersion)
        analytics.process(event: event)
    }
    
    func retrieveAppBundleIdentifier() -> String {
        if let bundle = Bundle.main.bundleIdentifier {
            return bundle
        }
        return ""
    }
    
    func retrieveAppVersion() -> String {
        if let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String {
            return version
        }
        return ""
    }
    
}
