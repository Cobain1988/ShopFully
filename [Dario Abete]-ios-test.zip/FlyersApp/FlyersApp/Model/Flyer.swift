//
//  Flyer.swift
//  FlyersApp
//
//  Created by Dario Abete on 23/09/2020.
//  Copyright © 2020 Dario Abete. All rights reserved.
//

import Foundation
import UIKit

class Flyer {
    let id: String
    let retailerId: String
    let title: String
    var isRead: Bool = false
    var imageView: UIImageView?
    var position: Int
    var sessionDuration: Int64 = 0
    
    init(id: String, retailerId: String, title: String, position: Int, imageView: UIImageView?) {
        self.id = id
        self.retailerId = retailerId
        self.title = title
        self.position = position
        self.imageView = imageView
    }
    
    func resetStatus() {
        self.isRead = true
        self.sessionDuration = 0
    }
}
