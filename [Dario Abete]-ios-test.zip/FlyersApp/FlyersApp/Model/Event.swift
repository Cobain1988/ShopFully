//
//  Event.swift
//  FlyersApp
//
//  Created by Dario Abete on 25/09/2020.
//  Copyright © 2020 Dario Abete. All rights reserved.
//

import Foundation

class Event: StreamFullyEvent {
    var eventType: String
    var attributes: [String: Any]
    
    init(eventType: String, attributes: [String: Any]) {
        self.eventType = eventType
        self.attributes = attributes
    }
}
