//
//  FlyersCollectionViewControllerExtension.swift
//  FlyersApp
//
//  Created by Dario Abete on 23/09/2020.
//  Copyright © 2020 Dario Abete. All rights reserved.
//

import Foundation
import UIKit

// MARK: CollectionViewFlowLayoutDelegate
extension FlyersCollectionViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.width - 15)/2, height: (collectionView.frame.size.width - 15)/2)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
    }
}

// MARK: Miscellaneous
extension FlyersCollectionViewController {
    func setActivityIndicator(indicator: UIActivityIndicatorView, style: UIActivityIndicatorView.Style) {
        self.view.addSubview(indicator)
        indicator.style = style
        indicator.hidesWhenStopped = true
        indicator.center = CGPoint(x: view.center.x, y: view.center.y-50)
        indicator.transform = CGAffineTransform(scaleX: 2, y: 2)
    }
    
    func displayMissingConnectionAlert() {
        let alert = UIAlertController(title: "Warning", message: "The Internet connection is not available. Please check your network status before trying again.", preferredStyle: .alert)
        let connectAction = UIAlertAction(title: "Try again", style: .default) { [self] (_) in
            try? self.addObserver()
        }
        alert.addAction(connectAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func populateView() {
        self.manager.fetchData { (array) in
            array.forEach { (elem) in
                guard let id = elem["id"] as? String else { return }
                let retailerId = elem["retailer_id"] as? String
                let title = elem["title"] as? String
                let position = array.firstIndex(where: {$0["id"] as? String == id })
                
                DispatchQueue.main.async {
                    let urlString = "https://it-it-media.shopfully.cloud/images/volantini​/" + "\(id)" + "@3x.jpg"
                    self.downloadImage(from: urlString) { (imageView) in
                        let flyer = Flyer(id: id, retailerId: retailerId ?? "No retailer id", title: title ?? "No title", position: position ?? -1, imageView: imageView )
                        self.flyerData.append(flyer)
                    }
                }
            }
            
            DispatchQueue.main.sync(execute: {
                if !self.flyerData.isEmpty {self.activityIndicator.stopAnimating()}
                self.collectionView.reloadData()
            })
        }
    }
    
    // MARK: download single pic from the url string
    func downloadImage(from urlString: String, completion: @escaping (UIImageView) -> ()) {
        
        let imageView = UIImageView()
        
        guard let url = URL(string: urlString) else {
            let image = UIImage(named: "no-image")
            imageView.image = image
            completion(imageView)
            return
        }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
            else { return }
            imageView.image = image
            completion(imageView)
            
        }.resume()
    }
}
