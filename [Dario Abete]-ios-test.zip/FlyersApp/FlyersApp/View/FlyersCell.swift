//
//  FlyersCell.swift
//  FlyersApp
//
//  Created by Dario Abete on 24/09/2020.
//  Copyright © 2020 Dario Abete. All rights reserved.
//

import UIKit

class FlyersCell: UICollectionViewCell {
    
    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var checkboxImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.borderColor = UIColor.black.cgColor
        self.layer.borderWidth = 2.0
    }
    
    func setup(text: String, isRead: Bool, imageView: UIImageView?) {
        productImageView.image = imageView?.image
        productImageView.alpha = 0.2
        titleLabel.text = text
        titleLabel.textColor = isRead ? UIColor.init(red: 0.0, green: 100/255, blue: 0.0, alpha: 1.0) : .red
        checkboxImageView.isHidden = !isRead
        checkboxImageView.image = UIImage(named: "checkbox")
    }
    
}
