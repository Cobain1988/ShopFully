//
//  ConnectionManager.swift
//  FlyersApp
//
//  Created by Dario Abete on 23/09/2020.
//  Copyright © 2020 Dario Abete. All rights reserved.
//

import Foundation

class APIManager {
    func fetchData(completion: @escaping ([[String: Any]])->() ) {
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration)
        let url = URL(string: "https://run.mocky.io/v3/94da1ce3-3d3f-414c-8857-da813df3bb05")
        
        session.dataTask(with: url!) { (data, _, error) in
            
            if error != nil {
                debugPrint(error!.localizedDescription)
            }
            
            guard let data = data else { return }
            
            do {
                guard let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String: Any] else { return }
                if let results = json["data"] as? [[String: Any]] {
                    completion(results)
                }
                
            } catch let jsonError {
                debugPrint(jsonError)
            }
            
        }.resume()
    }
}
