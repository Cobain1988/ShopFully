//
//  StreamFully.swift
//  FlyersApp
//
//  Created by Dario Abete on 25/09/2020.
//  Copyright © 2020 Dario Abete. All rights reserved.
//

import Foundation

protocol StreamFullyEvent {
    
    //event type
    var eventType: String { get }
    
    //attrributes list
    var attributes: [String: Any] { get }
}


struct StreamFully {
    
    let appIdentifier: String
    let appVersion: String
    
    init(appIdentifier: String, appVersion: String) {
        self.appIdentifier = appIdentifier
        self.appVersion = appVersion
    }
    
    func process(event: StreamFullyEvent) {
        print("App identifier: \(appIdentifier)")
        print("App version: \(appVersion)")
        print("Event type: \(event.eventType)")
        print("Event attributes: \(event.attributes.debugDescription)")
        print("\n")
    }
}
