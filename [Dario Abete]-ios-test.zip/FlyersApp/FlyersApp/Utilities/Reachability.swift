//
//  Reachability.swift
//  FlyersApp
//
//  Created by Dario Abete on 24/09/2020.
//  Copyright © 2020 Dario Abete. All rights reserved.
//

import Foundation
import Reachability

fileprivate var reachability: Reachability!

protocol ReachabilityAction {
    func reachabilityChanged(_ isReachable: Bool)
}

protocol ReachabilityObserver: class, ReachabilityAction {
    func addObserver() throws
    func removeObserver()
}

//default implementation
extension ReachabilityObserver {
    func addObserver() throws {
        
        reachability = try Reachability()
        
        reachability.whenReachable = { [weak self] reachability in
            self?.reachabilityChanged(true)
        }
        
        reachability.whenUnreachable = { [weak self] reachability in
            self?.removeObserver()
            self?.reachabilityChanged(false)
            
        }
        try reachability.startNotifier()
        
    }
    
    func removeObserver() {
        if let _ = reachability {
            reachability.stopNotifier()
            reachability = nil
        }
    }
}
